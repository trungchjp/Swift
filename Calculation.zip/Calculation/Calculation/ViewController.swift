//
//  ViewController.swift
//  Calculation
//
//  Created by Nguyễn Trung on 6/19/19.
//  Copyright © 2019 Nguyễn Trung. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var number: UITextField!
    @IBOutlet weak var btnPlus: UIButton!
    @IBOutlet weak var btnMinus: UIButton!
    
    
    @IBAction func btnPlus(_ sender: Any) {
        if(!checkInput()){
            return;
        }
        let a : Int = Int(number.text!)!;
        number.text = String.init(a + 1);
    }
    @IBAction func btnMinus(_ sender: Any) {
        if(!checkInput()){
            return;
        }
        let a : Int = Int(number.text!)!;
        number.text = String.init(a - 1);
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnMinus.layer.cornerRadius = 10;
        btnPlus.layer.cornerRadius = 10;
    }
    
    func showDialog() {
        // Hiển thị hộp thoại thông báo
        let ac = UIAlertController(title: "Thông báo", message: "Vui lòng nhập vào một số",preferredStyle: UIAlertController.Style.alert)
        ac.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default,handler: nil))
        self.present(ac, animated: true, completion: nil)
    }
    
    func checkInput() -> Bool {
        if(number.text!.isEmpty) {
            self.number.becomeFirstResponder();
            showDialog();
            return false;
        }
        return true;
    }


}

